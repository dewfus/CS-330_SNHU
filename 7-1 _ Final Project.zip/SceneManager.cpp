///////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
	m_loadedTextures = 0;
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/

void SceneManager::DestroyGLTextures() {

	for (int i = 0; i < m_loadedTextures; i++) {
		glGenTextures(1, &m_textureIDs[i].ID);
	}

}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/

/***********************************************************
 *  DefineObjectMaterials()
 *
 *  This method is used for configuring the various material
 *  settings for all of the objects within the 3D scene.
 *  Material properties follow the Phong lighting model:
 *    - ambientColor/Strength: base color visible in shadow
 *    - diffuseColor: color under direct diffuse illumination
 *    - specularColor/shininess: highlight color and tightness
 ***********************************************************/

void SceneManager::DefineObjectMaterials() {

	OBJECT_MATERIAL woodMaterial;
	OBJECT_MATERIAL metalMaterial;
	OBJECT_MATERIAL fabricMaterial;
	OBJECT_MATERIAL lampShadeMaterial;
	OBJECT_MATERIAL lampMetalMaterial;
	OBJECT_MATERIAL laptopMaterial;
	OBJECT_MATERIAL mugMaterial;
	OBJECT_MATERIAL leatherMaterial;

	woodMaterial.tag = "wood";
	woodMaterial.ambientColor = glm::vec3(0.35f, 0.28f, 0.2f);
	woodMaterial.ambientStrength = 0.3f;
	woodMaterial.diffuseColor = glm::vec3(0.05f, 0.04f, 0.03f);
	woodMaterial.specularColor = glm::vec3(0.02f, 0.02f, 0.02f);
	woodMaterial.shininess = 2.0f;
	m_objectMaterials.push_back(woodMaterial);

	metalMaterial.tag = "metal";
	metalMaterial.ambientColor = glm::vec3(0.5f, 0.5f, 0.5f);
	metalMaterial.ambientStrength = 0.65f;
	metalMaterial.diffuseColor = glm::vec3(0.3f, 0.3f, 0.3f);
	metalMaterial.specularColor = glm::vec3(0.8f, 0.8f, 0.8f);
	metalMaterial.shininess = 64.0f;
	m_objectMaterials.push_back(metalMaterial);

	fabricMaterial.tag = "fabric";
	fabricMaterial.ambientColor = glm::vec3(0.6f, 0.55f, 0.45f);
	fabricMaterial.ambientStrength = 0.65f;
	fabricMaterial.diffuseColor = glm::vec3(0.3f, 0.27f, 0.22f);
	fabricMaterial.specularColor = glm::vec3(0.01f, 0.01f, 0.01f);
	fabricMaterial.shininess = 1.0f;
	m_objectMaterials.push_back(fabricMaterial);

	lampShadeMaterial.tag = "lampShade";
	lampShadeMaterial.ambientColor = glm::vec3(0.6f, 0.55f, 0.4f);
	lampShadeMaterial.ambientStrength = 0.65f;
	lampShadeMaterial.diffuseColor = glm::vec3(0.3f, 0.27f, 0.2f);
	lampShadeMaterial.specularColor = glm::vec3(0.01f, 0.01f, 0.01f);
	lampShadeMaterial.shininess = 1.0f;
	m_objectMaterials.push_back(lampShadeMaterial);

	lampMetalMaterial.tag = "lampMetal";
	lampMetalMaterial.ambientColor = glm::vec3(0.7f, 0.7f, 0.7f);
	lampMetalMaterial.ambientStrength = 0.65f;
	lampMetalMaterial.diffuseColor = glm::vec3(0.3f, 0.3f, 0.3f);
	lampMetalMaterial.specularColor = glm::vec3(0.6f, 0.6f, 0.6f);
	lampMetalMaterial.shininess = 64.0f;
	m_objectMaterials.push_back(lampMetalMaterial);

	laptopMaterial.tag = "laptop";
	laptopMaterial.ambientColor = glm::vec3(0.7f, 0.7f, 0.7f);
	laptopMaterial.ambientStrength = 0.65f;
	laptopMaterial.diffuseColor = glm::vec3(0.4f, 0.4f, 0.4f);
	laptopMaterial.specularColor = glm::vec3(0.5f, 0.5f, 0.5f);
	laptopMaterial.shininess = 32.0f;
	m_objectMaterials.push_back(laptopMaterial);

	mugMaterial.tag = "mug";
	mugMaterial.ambientColor = glm::vec3(0.6f, 0.6f, 0.6f);
	mugMaterial.ambientStrength = 0.65f;
	mugMaterial.diffuseColor = glm::vec3(0.3f, 0.3f, 0.3f);
	mugMaterial.specularColor = glm::vec3(0.3f, 0.3f, 0.3f);
	mugMaterial.shininess = 16.0f;
	m_objectMaterials.push_back(mugMaterial);

	leatherMaterial.tag = "leather";
	leatherMaterial.ambientColor = glm::vec3(0.5f, 0.32f, 0.2f);
	leatherMaterial.ambientStrength = 0.65f;
	leatherMaterial.diffuseColor = glm::vec3(0.35f, 0.22f, 0.13f);
	leatherMaterial.specularColor = glm::vec3(0.05f, 0.05f, 0.05f);
	leatherMaterial.shininess = 4.0f;
	m_objectMaterials.push_back(leatherMaterial);

}

/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene

	m_basicMeshes->LoadPlaneMesh();

	// Loading the shape meshes for the scene
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadConeMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadTorusMesh();

	// loading the textures
	CreateGLTexture("../../Utilities/textures/metal.jpg", "metal");
	CreateGLTexture("../../Utilities/textures/fabric.jpg", "fabric");
	CreateGLTexture("../../Utilities/textures/wood.jpg", "wood");
	CreateGLTexture("../../Utilities/textures/leather.jpg", "leather");

	BindGLTextures();

	m_pShaderManager->setVec3Value("lightSources[0].position", -8.0f, 3.0f, 2.0f);
	m_pShaderManager->setVec3Value("lightSources[0].ambientColor", 1.2f, 1.14f, 1.08f);
	m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", 1.2f, 1.14f, 1.08f);
	m_pShaderManager->setVec3Value("lightSources[0].specularColor", 0.3f, 0.3f, 0.3f);
	m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 16.0f);
	m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 0.3f);

	m_pShaderManager->setVec3Value("lightSources[1].position", 8.0f, 3.0f, 2.0f);
	m_pShaderManager->setVec3Value("lightSources[1].ambientColor", 0.5f, 0.55f, 0.8f);
	m_pShaderManager->setVec3Value("lightSources[1].diffuseColor", 0.5f, 0.55f, 0.8f);
	m_pShaderManager->setVec3Value("lightSources[1].specularColor", 0.2f, 0.2f, 0.3f);
	m_pShaderManager->setFloatValue("lightSources[1].focalStrength", 16.0f);
	m_pShaderManager->setFloatValue("lightSources[1].specularIntensity", 0.2f);

	m_pShaderManager->setVec3Value("lightSources[2].position", 0.0f, 2.0f, -8.0f);
	m_pShaderManager->setVec3Value("lightSources[2].ambientColor", 0.8f, 0.8f, 0.8f);
	m_pShaderManager->setVec3Value("lightSources[2].diffuseColor", 0.6f, 0.6f, 0.6f);
	m_pShaderManager->setVec3Value("lightSources[2].specularColor", 0.0f, 0.0f, 0.0f);
	m_pShaderManager->setFloatValue("lightSources[2].focalStrength", 8.0f);
	m_pShaderManager->setFloatValue("lightSources[2].specularIntensity", 0.1f);

	DefineObjectMaterials();

	m_pShaderManager->setBoolValue(g_UseLightingName, true);

}

// Creating a RenderDeskLamp method that constructs our desk lamp
// The method is called in the RenderScene method to add the
// desk lamp to our plane.

void SceneManager::RenderDeskLamp()
{
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	// Creating the base of our desk lamp
	scaleXYZ = glm::vec3(1.2f, 0.2f, 1.2f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-4.0f, 0.0f, -3.0f);

	SetTransformations(
		scaleXYZ, 
		XrotationDegrees, 
		YrotationDegrees,
		ZrotationDegrees, 
		positionXYZ
	);

	// adding texture and UV scale to the lamp base
	SetShaderTexture("metal");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("lampMetal");

	m_basicMeshes->DrawCylinderMesh();

	// Creating the cylinder arm of our desk lamp
	scaleXYZ = glm::vec3(0.12f, 3.5f, 0.12f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-4.0f, 0.2f, -3.0f);

	SetTransformations(
		scaleXYZ, 
		XrotationDegrees, 
		YrotationDegrees,
		ZrotationDegrees, 
		positionXYZ
	);

	// adding texture and UV scale to the lamp arm
	SetShaderTexture("metal");
	SetTextureUVScale(1.0f, 3.0f);
	SetShaderMaterial("lampMetal");

	m_basicMeshes->DrawCylinderMesh();

	// Providing our scale, rotation, and positioning for
	// our lamp shade (our cone mesh)
	scaleXYZ = glm::vec3(1.0f, 1.2f, 1.0f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 180.0f;
	positionXYZ = glm::vec3(-4.0f, 4.2f, -3.0f);

	SetTransformations(
		scaleXYZ, 
		XrotationDegrees, 
		YrotationDegrees,
		ZrotationDegrees, 
		positionXYZ
	);

	// adding texture and UV scale to the lamp shade
	SetShaderTexture("fabric");
	SetTextureUVScale(2.0f, 1.0f);
	SetShaderMaterial("lampShade");

	m_basicMeshes->DrawConeMesh();

}

void SceneManager::RenderBook() {

	glm::vec3 scaleXYZ;
	glm::vec3 positionXYZ;

	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;

	scaleXYZ = glm::vec3(2.0f, 0.18f, 1.4f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 15.0f;  
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(1.5f, 0.09f, -1.5f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ
	);

	SetShaderTexture("leather");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("leather");

	m_basicMeshes->DrawBoxMesh();

}

void SceneManager::RenderCoffeeMug()
{
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	scaleXYZ = glm::vec3(0.45f, 0.9f, 0.45f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(1.5f, 0.0f, 1.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ
	);

	SetShaderTexture("fabric"); 
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("mug");

	m_basicMeshes->DrawCylinderMesh();

	scaleXYZ = glm::vec3(0.22f, 0.22f, 0.12f);
	XrotationDegrees = 0.0f;      
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(1.95f, 0.5f, 1.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("fabric");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("mug");

	m_basicMeshes->DrawTorusMesh();

}

void SceneManager::RenderLaptop()
{
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	scaleXYZ = glm::vec3(3.2f, 0.12f, 2.2f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(5.0f, 0.06f, -0.5f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ
	);

	SetShaderTexture("metal");
	SetTextureUVScale(2.0f, 1.0f);
	SetShaderMaterial("laptop");

	m_basicMeshes->DrawBoxMesh();

	scaleXYZ = glm::vec3(3.2f, 2.0f, 0.06f);
	XrotationDegrees = -25.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(5.0f, 1.013f, -1.99f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ
	);

	SetShaderTexture("metal");
	SetTextureUVScale(2.0f, 1.5f);
	SetShaderMaterial("laptop");

	m_basicMeshes->DrawBoxMesh();
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// also providing a texture for the plane
	// in this case, the surface of the desk
	SetShaderTexture("wood");
	SetTextureUVScale(4.0f, 4.0f);
	SetShaderMaterial("wood");

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();
	/****************************************************************/

	RenderDeskLamp();
	RenderBook();
	RenderCoffeeMug();
	RenderLaptop();

}
